{ pkgs, inputs, ... }:
let
  packages = with pkgs; [
    fish
  ];
in
{
  imports = [
    inputs.home-manager.nixosModules.home-manager
  ];

  home-manager = {
    useUserPackages = true;
    useGlobalPkgs = true;
    extraSpecialArgs = { inherit inputs; };
    users.marcelo = {
      imports = [
        (import ./home)
      ];
      home.username = "marcelo";
      home.homeDirectory = "/home/marcelo";
      home.stateVersion = "23.11";
      programs.home-manager.enable = true;
    };
  };

  users.users.marcelo = {
    isNormalUser = true;
    description = "marcelo";
    extraGroups = [ "networkmanager" "input" "wheel" "video" "audio" ];
    shell = pkgs.zsh;
  };

  nix.settings.allowed-users = [ "marcelo" ];
}