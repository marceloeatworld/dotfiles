{ pkgs, ... }: 
{
  packages = (with pkgs; [ floorp ]);
}
