{

  description = "Marcelo NixOS Configuration";
  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
    #nur.url = "github:nix-community/NUR";
  
    disko.url = "github:nix-community/disko";
    disko.inputs.nixpkgs.follows = "nixpkgs";

    hypr-contrib.url = "github:hyprwm/contrib";
    hyprpicker.url = "github:hyprwm/hyprpicker";
  
    alejandra.url = "github:kamadorueda/alejandra/3.0.0";
  
    nix-gaming.url = "github:fufexan/nix-gaming";
  
    hyprland = {
      url = "github:hyprwm/Hyprland";
      inputs.nixpkgs.follows = "nixpkgs";
    };
  
    #home-manager = {
      #url = "github:nix-community/home-manager";
     # inputs.nixpkgs.follows = "nixpkgs";
    #};

    catppuccin-bat = {
      url = "github:catppuccin/bat";
      flake = false;
    };
    catppuccin-cava = {
      url = "github:catppuccin/cava";
      flake = false;
    };
    catppuccin-starship = {
      url = "github:catppuccin/starship";
      flake = false;
    };
  };

  outputs = { nixpkgs, disko, ... } @ inputs:
    {
    
    nixosConfigurations.nixos = nixpkgs.lib.nixosSystem {
      specialArgs = { inherit inputs self nixpkgs; };
      system = "x86_64-linux";
      modules = [
        disko.nixosModules.disko
        ./bootloader.nix
        ./configuration.nix
        ./hardware-configuration.nix
        ./hardware.nix
        ./virtualisation.nix
        ./wayland.nix
        ./xserver.nix
        ./network.nix
        ./security-services.nix
        ./services.nix
        ./sound.nix
        ./steam.nix
        ./system.nix
        ./user.nix
      ];
    };
  };
}
