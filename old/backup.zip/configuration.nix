# Edit this configuration file to define what should be installed on
# your system. Help is available in the configuration.nix(5) man page, on
# https://search.nixos.org/options and in the NixOS manual (`nixos-help`).

{ config, lib, pkgs, ... }:

{
  imports =
    [ # Include the results of the hardware scan.
      ./hardware-configuration.nix
      ./disko-config.nix
    ];

  # Use the systemd-boot EFI boot loader.
  #boot.loader.systemd-boot.enable = true;
  boot.loader.grub.enable = true;
  boot.loader.grub.efiSupport = true;
  boot.loader.grub.efiInstallAsRemovable = true;
  #boot.loader.efi.canTouchEfiVariables = true;
  boot.tmp.cleanOnBoot = true;
boot.initrd.kernelModules = [ "amdgpu" ];
  # networking.hostName = "nixos"; # Define your hostname.
  # Pick only one of the below networking options.
  # networking.wireless.enable = true;  # Enables wireless support via wpa_supplicant.
#   networking.networkmanager.enable = true;  # Easiest to use and most distros use this by default.
#    console.keyMap = "fr";
  environment.sessionVariables = {
    NIXOS_OZONE_WL = "1";
    # WAYLAND_DISPLAY = "wayland-1";
    # GTK_THEME = "adwaita:dark";
    XDG_CACHE_HOME = "$HOME/.cache";
    XDG_CONFIG_HOME = "$HOME/.config";
    XDG_DATA_HOME = "$HOME/.local/share";
    XDG_STATE_HOME = "$HOME/.local/state";
    XDG_BIN_HOME = "$HOME/.local/bin";
  };
hardware = {
    bluetooth = {
      enable = true;
      settings = { General = { Experimental = true; }; };
    };
    pulseaudio = { enable = false; };
  };
  nix = {
    settings = {
      auto-optimise-store = true;
      experimental-features = [ "nix-command" "flakes" ];
    };
  };

  security.rtkit.enable = true;
  sound.enable = true;
  system.autoUpgrade.enable = true;
systemd.tmpfiles.rules = [
    "L+    /opt/rocm/hip   -    -    -     -    ${pkgs.rocmPackages.clr}"
  ];
virtualisation = {
    docker.enable = true;
    libvirtd.enable = true;
  };
  networking = {
    enableIPv6 = true;
    networkmanager.enable = true;
  };
  # Set your time zone.
   time.timeZone = "Europe/Paris";

  # Configure network proxy if necessary
  # networking.proxy.default = "http://user:password@proxy:port/";
  # networking.proxy.noProxy = "127.0.0.1,localhost,internal.domain";
 fonts = {
    packages = with pkgs; [
        jetbrains-mono
    nerd-font-patcher
    ];
    #fontconfig.defaultFonts = {
     # serif = [ "Noto Serif" "Source Han Serif" ];
     # sansSerif = [ "Noto Sans" "Source Han Sans" ];
    #};
  };

  # Select internationalisation properties.
#   i18n.defaultLocale = "en_US.UTF-8";
 i18n = {
    defaultLocale = "en_US.UTF-8";
    extraLocaleSettings = {
      LC_ADDRESS = "fr_FR.UTF-8";
      LC_IDENTIFICATION = "fr_FR.UTF-8";
      LC_MEASUREMENT = "fr_FR.UTF-8";
      LC_MONETARY = "fr_FR.UTF-8";
      LC_NAME = "fr_FR.UTF-8";
      LC_NUMERIC = "fr_FR.UTF-8";
      LC_PAPER = "fr_FR.UTF-8";
      LC_TELEPHONE = "fr_FR.UTF-8";
      LC_TIME = "fr_FR.UTF-8";
    };
  };

  # console = {
  #   font = "Lat2-Terminus16";
  #   keyMap = "us";
  #   useXkbConfig = true; # use xkb.options in tty.
  # };

  # Enable the X11 windowing system.
#  services.xserver.enable = true;

  services = {
   # udev.extraRules = ''
    # KERNEL=="hidraw*", SUBSYSTEM=="hidraw", ATTRS{serial}=="*vial:f64c2b3c*", MODE="0660", GROUP="users", TAG+="uaccess", TAG+="udev-acl"
     # KERNEL=="hidraw*", SUBSYSTEM=="hidraw", MODE="0660", GROUP="users", TAG+="uaccess", TAG+="udev-acl"
   # '';
    tailscale = {
      enable = true;
      extraUpFlags = [ "--ssh" ];
    };
    xserver.enable = true;
    
    xserver.videoDrivers = [ "amdgpu" ];
    xserver.displayManager.sddm.enable = true;
    #xserver.desktopManager.gnome.enable = false;
    
    mullvad-vpn.enable = true;
    passSecretService.enable = true;
    resolved.enable = true;
    udisks2.enable = true;
   xserver = {
      xkb = {
        layout = "fr, us";
       variant = "nodeadkeys";
      };
    };
    pipewire = {
      enable = true;
      alsa.enable = true;
      alsa.support32Bit = true;
      pulse.enable = true;
    };
  };

  nixpkgs = {
    config = {
      allowUnfree = true;
      allowUnsupportedSystem = true;
      
    };
  };
  

  # Configure keymap in X11
  # services.xserver.xkb.layout = "us";
  # services.xserver.xkb.options = "eurosign:e,caps:escape";

  # Enable CUPS to print documents.
  # services.printing.enable = true;

  # Enable sound.
#  sound.enable = true;
#  hardware.pulseaudio.enable = true;

  # Enable touchpad support (enabled default in most desktopManager).
  # services.xserver.libinput.enable = true;

  # Define a user account. Don't forget to set a password with ‘passwd’.
  users.users.marcelo = {
     isNormalUser = true;
     extraGroups = [ 
"wheel"
"docker"
"keyd"
          "networkmanager"
          "dialout"
          "libvirtd"
          "wireshark"
          "adbusers"
          "input"
          "plugdev" 

]; # Enable ‘sudo’ for the user.
     packages = with pkgs; [
       brave
kitty
waybar
xdg-desktop-portal-hyprland
htop
file
vscode-fhs

helix
unzip
somebar
unrar-wrapper
tree       
tmux
discord
    slurp
    somebar
    stylua
    swappy
    swaybg
wl-clipboard
wtype
xdg-utils
spotify
swaylock-effects
pyprland
 rofi-wayland
    dunst
     ];
   };
  
programs = {
    # tmux = {
    #   enable = true;
    #   escapeTime = 0;
    #   plugins = with pkgs.tmuxPlugins; [ tmux-sensible resurrect ];
    #   extraConfig = ''
    #     set -g status-right '%Y-%m-%d %H:%M #{tmux_mode_indicator}'
    #   '';
    # };
    steam = {
      enable = true;
      remotePlay.openFirewall =
        true; # Open ports in the firewall for Steam Remote Play
      dedicatedServer.openFirewall =
        true; # Open ports in the firewall for Source Dedicated Server
    };
    hyprland.enable = true;
    dconf.enable = true;
    # wireshark.enable = true;
       zsh = {
      enable = true;
      # ohMyZsh.enable = true;
      # ohMyZsh.plugins = [ "zoxide" "git" "thefuck" "powerlevel10k" ];
      autosuggestions.enable = false;
      syntaxHighlighting.enable = true;
      shellAliases = {
        # cd = "zoxide";
        cd = "z";
        ip = "ip --color=always";
        ssh = "TERM=xterm ssh";
        k = "kubectl";
        update = "sudo nixos-rebuild switch --upgrade";
        lg = "lazygit";
        upload = "~/dotfiles/scripts/upload.sh";
        vi = "nvim";
        blue = "bluetuith";
      }; 
    };
  };
  # List packages installed in system profile. To search, run:
  # $ nix search wget
   environment.systemPackages = with pkgs; [
     vim # Do not forget to add an editor to edit configuration.nix! The Nano editor is also installed by default.
     wget
   ];

  # Some programs need SUID wrappers, can be configured further or are
  # started in user sessions.
  # programs.mtr.enable = true;
  # programs.gnupg.agent = {
  #   enable = true;
  #   enableSSHSupport = true;
  # };

  # List services that you want to enable:

  # Enable the OpenSSH daemon.
  # services.openssh.enable = true;

  # Open ports in the firewall.
  # networking.firewall.allowedTCPPorts = [ ... ];
  # networking.firewall.allowedUDPPorts = [ ... ];
  # Or disable the firewall altogether.
  # networking.firewall.enable = false;

  # Copy the NixOS configuration file and link it from the resulting system
  # (/run/current-system/configuration.nix). This is useful in case you
  # accidentally delete configuration.nix.
  # system.copySystemConfiguration = true;

  # This option defines the first version of NixOS you have installed on this particular machine,
  # and is used to maintain compatibility with application data (e.g. databases) created on older NixOS versions.
  #
  # Most users should NEVER change this value after the initial install, for any reason,
  # even if you've upgraded your system to a new NixOS release.
  #
  # This value does NOT affect the Nixpkgs version your packages and OS are pulled from,
  # so changing it will NOT upgrade your system.
  #
  # This value being lower than the current NixOS release does NOT mean your system is
  # out of date, out of support, or vulnerable.
  #
  # Do NOT change this value unless you have manually inspected all the changes it would make to your configuration,
  # and migrated your data accordingly.
  #
  # For more information, see `man configuration.nix` or https://nixos.org/manual/nixos/stable/options#opt-system.stateVersion .
  system.stateVersion = "23.11"; # Did you read the comment?

}

