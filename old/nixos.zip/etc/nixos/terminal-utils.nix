{ pkgs, ... }:

{
  environment.systemPackages = with pkgs; [
    nixos-generators
    upx
    git
    lazygit
    license-generator
    git-ignore
    pass-git-helper
    progress
    noti
    topgrade
    ripgrep
    rewrk
    wrk2
    procs
    sd
    duf
    fd
    gh
  ];
}
