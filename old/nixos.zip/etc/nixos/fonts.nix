{ pkgs, ... }:

{
  # Fonts
  fonts.packages = with pkgs; [
    jetbrains-mono
    nerd-font-patcher
    cantarell-fonts
    iosevka
    fira-code
    comic-mono
    nerdfonts
    fantasque-sans-mono
    ];
}
