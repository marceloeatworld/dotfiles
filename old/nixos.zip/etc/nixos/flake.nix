{

  description = "Marcelo NixOS Configuration";
  inputs = {
      nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
      #rust-overlay.url = "github:oxalica/rust-overlay";
      hyprland.url = "github:hyprwm/Hyprland";
      disko.url = "github:nix-community/disko";
      disko.inputs.nixpkgs.follows = "nixpkgs";
  };

  outputs = { nixpkgs, disko, hyprland, ... } @ inputs:
  {
    nixosConfigurations.nixos = nixpkgs.lib.nixosSystem {
      specialArgs = { inherit inputs; };
      system = "x86_64-linux";
      modules = [
        disko.nixosModules.disko
        ./steam.nix
        ./xserver.nix
        ./configuration.nix
        ./disko-config.nix
        ./hardware-configuration.nix
        ./sound.nix
        ./usb.nix
        ./time.nix
        ./swap.nix
        ./nix-settings.nix
        ./nixpkgs.nix
        ./gc.nix
	      ./bootloader.nix        
        ./screen.nix
        ./display-manager.nix
        ./theme.nix
        ./internationalisation.nix
        ./fonts.nix
        ./security-services.nix
        ./services.nix
        ./hyprland.nix
        ./environment-variables.nix
        ./bluetooth.nix
        ./networking.nix
        ./firewall.nix
        ./dns.nix
        ./users.nix
        ./virtualisation.nix
        ./programming-languages.nix
        ./lsp.nix
        #./rust.nix
        #./wasm.nix
        ./info-fetchers.nix
        ./utils.nix
        ./terminal-utils.nix
        #./work.nix
      ];
    };
  };
}
