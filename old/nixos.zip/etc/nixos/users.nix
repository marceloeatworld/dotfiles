{ pkgs, ... }:

{
  # Define a user account. Don't forget to set a password with ‘passwd’.
  users.users.marcelo = {
    isNormalUser = true;
    description = "marcelo";
    extraGroups = [ "networkmanager" "input" "wheel" "video" "audio" ];
    shell = pkgs.zsh;
    packages = with pkgs; [
      kitty
      
      zip
      unzip
      spotify
      discord
      #tdesktop
      vscode-fhs
      brave
      whatsapp-for-linux
    ];
  };

  # Change runtime directory size
  #services.logind.extraConfig = "RuntimeDirectorySize=8G";
}
