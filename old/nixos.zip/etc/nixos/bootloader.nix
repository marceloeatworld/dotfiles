{ pkgs,  ... }:

{
  # Bootloader.
  boot.loader.grub.enable = true;
  boot.loader.grub.efiSupport = true;
  boot.loader.grub.efiInstallAsRemovable = true;
  boot.loader.timeout = 2;
  boot.tmp.cleanOnBoot = true;
  #boot.initrd.kernelModules = [ "amdgpu" ];
 # boot.plymouth = {
  #  enable = true;
   # font = "${pkgs.jetbrains-mono}/share/fonts/truetype/JetBrainsMono-Regular.ttf";
    #themePackages = [ pkgs.catppuccin-plymouth ];
    #theme = "catppuccin-macchiato";
  #};
}
