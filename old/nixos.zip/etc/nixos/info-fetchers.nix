{ pkgs, ... }:

{
  environment.systemPackages = with pkgs; [
    neofetch
    cpufetch
    htop
    kmon
    dig
    speedtest-rs
  ];
}
