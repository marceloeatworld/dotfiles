{ ... }:

{
  zramSwap.enable = true;
}
