{ pkgs, ... }:

{
  # Define a user account. Don't forget to set a password with ‘passwd’.
  users.users.marcelo = {
    isNormalUser = true;
    description = "marcelo";
    extraGroups = [ "networkmanager" "input" "wheel" "video" "audio" "tss" ];
    shell = pkgs.fish;
    packages = with pkgs; [
kitty
unzip
      spotify
      #youtube-music
      discord
      tdesktop
      vscode-fhs
      brave
    ];
  };

  # Change runtime directory size
  #services.logind.extraConfig = "RuntimeDirectorySize=8G";
}
